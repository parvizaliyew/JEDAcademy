<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SubscripeMessageController extends Controller
{
    public function contact_post(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'email'=>'required',
        ],
        [
            'email.required' =>'Zəhmət olmasa emailinizi daxil edin',
        ]);



        if($validator->fails()){
            return  redirect()->back()->withErrors($validator);
        }
            $message = new Subscripe;
    
            $email = "eliyevperviz466@gmail.com";
            $title= 'JEDAcademy saytindan mesaj var';
    
            $data = [
                'email'  => $request->email,
            ];
            Mail::send('mail.sendmail', $data, function($m) use ($title,$email) {
                $m->from(env('MAIL_FROM_ADDRESS'), env('APP_NAME'));
                $m->to($email, env('MAIL_FROM_NAME') )->subject($title);
            });
            
                $message->save();
                toastr()->success('Abunə olundu ən son yeniliklərdən sizə xəbərdaliq ediləcək');
                return redirect()->back();
    }
}

<?php

namespace App\Http\Controllers\Front;

use App\Models\Seo;
use App\Models\Alumni;
use App\Models\Course;
use App\Models\WhoCourseFor;
use App\Models\Sillabus;
use App\Models\Salary;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CoursesController extends Controller
{
    public function index()
    {
        $courses_seo=Seo::where('type',9)->orderBy('id','DESC')->first();
        $courses=Course::get();
        return view('front.pages.course',compact('courses_seo','courses'));
    }
    public function single($slug)
    {
        $courses=Course::get();
        $course=Course::whereJsonContains('slug->az',$slug)->orWhereJsonContains('slug->en',$slug)->orWhereJsonContains('slug->ru',$slug)->with('teachers')->first();
        $sillabus=Sillabus::where('course_id',$course->id)->first() ?? 0;
        $salary=Salary::where('course_id',$course->id)->orderBy('id','DESC')->first();
        $alumnis=Alumni::get();
        $who_courses=WhoCourseFor::where('course_id',$course->id)->get();
        return view('front.pages.course_single',compact('course','courses','sillabus','alumnis','who_courses','salary'));    
    }
}
